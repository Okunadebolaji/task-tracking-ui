import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskService } from '../../../services/task.service';
import { UsersService } from '../../../services/user.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../../services/auth';
import { TaskStatusService } from '../../../services/taskstatus.service';

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './view.html'
})
export class View implements OnInit {

  projects: any[] = [];
  tasks: any[] = [];
  page = 1;
  pageSize = 6;
  totalPages = 0;
  totalCount = 0;

  selectedProjectId?: number;

 selectedStatusId?: number;


statuses: { id: number; name: string }[] = [];

  selectedTeamId?: number;

  constructor(private taskService: TaskService, public usersService: UsersService,
              private http: HttpClient, private authService: AuthService, public taskStatusService: TaskStatusService) {}

  ngOnInit() {
    this.loadTasks();
    this.loadProjects();
    this.loadStatuses();
  }

 loadTasks(page = 1) {
  const user = this.authService.getCurrentUserSafe();
  if (!user) return;

 this.taskService.getTasks(
  page,
  this.pageSize,
  this.selectedProjectId,
  this.selectedStatusId,     // ✅ number
  this.selectedTeamId
).subscribe(res => {
    this.tasks = res.data;
    this.page = res.page;
    this.totalPages = res.totalPages;
    this.totalCount = res.totalCount;
  });
}

loadStatuses() {
  const user = this.authService.getCurrentUserSafe();
  if (!user) return;

  this.taskStatusService.getStatuses()
    .subscribe(res => {
      this.statuses = res;
    });
}


  loadProjects() {
    this.http.get<any[]>('http://localhost:5229/api/projects')
      .subscribe(res => this.projects = res);
  }

  statusClass(status: { id: number; name: string }) {
    switch (status?.name) {
      case 'Pending': return 'bg-secondary';
      case 'In Progress': return 'bg-info text-dark';
      case 'Completed': return 'bg-success';
      case 'Rejected': return 'bg-danger';
      default: return 'bg-light text-dark';
    }
  }

  nextPage() { if (this.page < this.totalPages) this.loadTasks(this.page + 1); }
  prevPage() { if (this.page > 1) this.loadTasks(this.page - 1); }
  approve(id: number) { this.taskService.approveTask(id).subscribe(() => this.loadTasks()); }
  reject(id: number) { this.taskService.rejectTask(id).subscribe(() => this.loadTasks()); }
  delete(id: number) { if (!confirm('Delete task?')) return; this.taskService.deleteTask(id).subscribe(() => this.loadTasks()); }
}
