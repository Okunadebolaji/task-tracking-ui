import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService } from '../../services/task.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { TaskStatusService } from '../../services/taskstatus.service';

@Component({
  selector: 'app-tasks',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tasks.html',
  styleUrls: ['./tasks.css']
})
export class TasksComponent implements OnInit {

  activeTab: 'view' | 'create' | 'pending' = 'view';

  tasks: any[] = [];
  projects: any[] = [];
  teams: any[] = [];
  requirements: any[] = [];
teamMembers : any[] = [];
  page = 1;
  pageSize = 20;
  totalPages = 0;
  totalCount = 0;

  selectedProjectId?: number;
 statuses: { id: number; name: string }[] = [];
 selectedStatusId?: number;


  selectedTeamId?: number;

  canCreate = false;
  canApprove = false;
  canReject = false;
  canDelete = false;

  taskForm = {
    module: '',
    description: '',
    references: '',
    comment: '',
    startDate: '',
    endDate: '',
  statusId: undefined as number | undefined,
   source: 'Manual',
    projectId: null as number | null,
    teamId: null as number | null,
    requirementIds: [] as number[],
     assignedUserIds: [] as number[]

  };

  constructor(private taskService: TaskService,
              private http: HttpClient,
              private router: Router,
              private authService: AuthService,
            public taskStatusService: TaskStatusService) {}

  ngOnInit() {
    const user = this.authService.getCurrentUserSafe();
    if (!user) {
      console.warn('No user in storage, redirecting to login');
      this.router.navigate(['/login']);
      return;
    }

    this.canCreate = true;
    this.canApprove = ['Admin', 'SuperAdmin'].includes(user.roleName);
    this.canReject = this.canApprove;
    this.canDelete = this.canApprove;
 this.loadStatuses();
    this.loadTasks();
    this.loadProjects();
  }

  loadTasks(page: number = 1) {
    const user = this.authService.getCurrentUserSafe();
    if (!user) {
      this.router.navigate(['/login']);
      return;
    }

    this.taskService.getTasks(page, this.pageSize, this.selectedProjectId, this.selectedStatusId, this.selectedTeamId)
      .subscribe(res => {
        this.tasks = res.data;
        this.page = res.page;
        this.pageSize = res.pageSize;
        this.totalPages = res.totalPages;
        this.totalCount = res.totalCount;
      });
  }

  createTask() {
    const user = this.authService.getCurrentUserSafe();
    if (!user) return;

    const payload = { ...this.taskForm, createdByUserId: user.id, companyId: user.companyId };

    this.taskService.createTask(payload).subscribe({
      next: () => {
        alert('Task created successfully');
        this.resetForm();
        this.loadTasks();
      },
      error: err => alert(err.error)
    });
  }

  loadProjects() {
    this.http.get<any[]>('http://localhost:5229/api/projects')
      .subscribe(r => this.projects = r);
  }

  onProjectChange(projectId: number | null) {
  if (!projectId) return;

  this.taskForm.teamId = null;
  this.taskForm.requirementIds = [];

  this.http
    .get<any[]>(`http://localhost:5229/api/teams/by-project/${projectId}`)
    .subscribe(teams => (this.teams = teams));

  this.http
    .get<any[]>(`http://localhost:5229/api/requirements/by-project/${projectId}`)
    .subscribe(reqs => (this.requirements = reqs));
}


  resetForm() {
    this.taskForm = {
      module: '',
      description: '',
      references: '',
      comment: '',
      startDate: '',
      endDate: '',
      statusId: 0,
      source: 'Manual',
      projectId: null,
      teamId: null,
      requirementIds: [],
      assignedUserIds:[]
    };
    this.teams = [];
    this.requirements = [];
  }

loadStatuses() {
  this.taskStatusService.getStatuses().subscribe(res => {
    this.statuses = res;

    const defaultStatus = res.find(s => s.isDefault);
    if (defaultStatus) {
      this.taskForm.statusId = defaultStatus.id;
    }
  });
}




  approve(id: number) { this.taskService.approveTask(id).subscribe(() => this.loadTasks()); }
  reject(id: number) { this.taskService.rejectTask(id).subscribe(() => this.loadTasks()); }
  delete(id: number) { if (!confirm('Delete task?')) return; this.taskService.deleteTask(id).subscribe(() => this.loadTasks()); }
}
