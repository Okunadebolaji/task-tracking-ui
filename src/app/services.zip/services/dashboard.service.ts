import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DashboardCounters } from '../Models/dashboard-counter.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private baseUrl = 'http://localhost:5229/api/dashboard';

  constructor(private http: HttpClient) {}

  getCounters(): Observable<DashboardCounters> {
    return this.http.get<DashboardCounters>(`${this.baseUrl}/counters`);
  }
}
