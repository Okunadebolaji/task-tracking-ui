import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class TaskStatusService {
  private baseUrl = 'http://localhost:5229/api/taskstatuses';

  constructor(private http: HttpClient) {}

  getStatuses() {
    return this.http.get<{ id: number; name: string; isDefault: boolean }[]>(`${this.baseUrl}`);
  }
}
