import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class CompanyService {
  private baseUrl = 'http://localhost:5229/api/companies';

  constructor(private http: HttpClient) {}

  getProfile() {
    return this.http.get<any>(`${this.baseUrl}/profile`);
  }

  updateProfile(name: string) {
    return this.http.put<any>(`${this.baseUrl}/profile`, { name });
  }
}
