import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Menu } from '../Models/menu.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class MenuService {
  public menus: Menu[] = [];
  private baseUrl = 'http://localhost:5229/api';

  constructor(private http: HttpClient) {}

  loadMenusByRole() {
    return this.http.get<Menu[]>(`${this.baseUrl}/menus/by-role`);
  }
}
